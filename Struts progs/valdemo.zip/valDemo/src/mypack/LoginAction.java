package mypack;

import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport
{
String name,password;

@Override
public void validate() {
	if(name.length()==0)
		addFieldError("name",
				getText("name.required"));
	if(password.length()==0)
		addFieldError("password",
				getText("password.required"));
	else if(password.length()<5)
		addFieldError("password",
				getText("password.minLength"));

}
public String execute()
{
return "success";	
}
public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

}

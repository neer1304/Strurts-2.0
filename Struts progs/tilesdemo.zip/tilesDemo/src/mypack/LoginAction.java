package mypack;

import db.User;
import db.UserDao;

public class LoginAction {

User user;

public String execute()
{
UserDao dao=new UserDao();

if (dao.find(user))
	return "success";
else
	return "failure";
}

public User getUser() {
	return user;
}

public void setUser(User user) {
	this.user = user;
}



}

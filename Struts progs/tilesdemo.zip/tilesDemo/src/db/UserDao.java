package db;

import java.sql.*;

public class UserDao {

	public boolean find (User user)
	{
		boolean flag=false;
		try
		{
Connection con=
	ConnectionProvider.getConnection();
PreparedStatement stmt=con.prepareStatement("select id,name from userInfo where mailId=? and password=?");
stmt.setString(1, user.getMailId());
stmt.setString(2, user.getPassword());
ResultSet rset=stmt.executeQuery();
if (rset.next())
{
				flag=true;
				user.setId(rset.getInt(1));
				user.setName(rset.getString(2));
				
				
			}
		}catch(Exception ex)
		{
			System.out.println(ex);
			
		}
		return flag;
	}
}
